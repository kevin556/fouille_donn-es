#/usr/bin/python2.7

1 ere etape:
user_name,id,ville,sexe,age.

2 eme etape:
	cold start.
	4 films a choisir parmi les plus recents (min 3 ans).
	4 films random.(bien sur différent).

3 eme étape:
	calcul lancé,pour le placer parmi les personnes avec les mecs caractérisitiques.